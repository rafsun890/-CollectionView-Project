//
//  CollectionViewCell.swift
//  CollectionView Project
//
//  Created by Tanim on 21/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var cellImg: UIImageView!
    @IBOutlet weak var cellTitle: UILabel!
    @IBOutlet weak var cellPrice: UILabel!
    
    func setProduct(product: Products){
        cellImg.image = product.image
        cellTitle.text = product.title
        cellPrice.text = product.price
    }
}
