//
//  Product.swift
//  CollectionView Project
//
//  Created by Tanim on 21/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

class Product: NSObject {

}

class Products{
    var image: UIImage?
    var title: String?
    var price: String?
    
    init (image: UIImage, title: String, price: String) {
        self.image = image
        self.title = title
        self.price = price
    }
}
