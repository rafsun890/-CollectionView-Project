//
//  ViewController.swift
//  CollectionView Project
//
//  Created by Tanim on 21/1/20.
//  Copyright © 2020 USER. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    @IBOutlet weak var productCollectionView: UICollectionView!
    
    var useProduct:[Products] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        productCollectionView.delegate = self
        productCollectionView.dataSource = self
        
        let layout = self.productCollectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.sectionInset = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
        layout.minimumInteritemSpacing = 5
        layout.itemSize = CGSize(width: (self.productCollectionView.frame.size.width-20)/2, height: (self.productCollectionView.frame.size.height/3))
            
        useProduct = createArray()
    }
    
    func createArray() -> [Products]{
        var tempArr : [Products] = []
               
        let v1 = Products(image: #imageLiteral(resourceName: "img1"), title: "Pineapple Box",price:"100.0")
        let v2 = Products(image: #imageLiteral(resourceName: "img2"), title: "Pineapple",price:"200.0")
        let v3 = Products(image: #imageLiteral(resourceName: "img3"), title: "Lemon",price:"100.0")
        let v4 = Products(image: #imageLiteral(resourceName: "img4"), title: "Watermelon",price:"100.0")
        let v5 = Products(image: #imageLiteral(resourceName: "img5"), title: "Strawberry",price:"100.0")
        let v6 = Products(image: #imageLiteral(resourceName: "img6"), title: "Apple",price:"100.0")
        let v7 = Products(image: #imageLiteral(resourceName: "img7"), title: "Orange",price:"100.0")
        let v8 = Products(image: #imageLiteral(resourceName: "img8"), title: "Malta",price:"100.0")
               
               tempArr.append(v1)
               tempArr.append(v2)
               tempArr.append(v3)
               tempArr.append(v4)
               tempArr.append(v5)
               tempArr.append(v6)
               tempArr.append(v7)
               tempArr.append(v8)
               
               return tempArr
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //print(useProduct.count)
        return useProduct.count
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = productCollectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! CollectionViewCell
        cell.setProduct(product:useProduct[indexPath.item])
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 1
        return cell
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = productCollectionView.cellForItem(at: indexPath)
        cell?.layer.borderColor = UIColor.red.cgColor
        cell?.layer.borderWidth = 2
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let cell = productCollectionView.cellForItem(at: indexPath)
        cell?.layer.borderColor = UIColor.lightGray.cgColor
        cell?.layer.borderWidth = 1
    }
}

